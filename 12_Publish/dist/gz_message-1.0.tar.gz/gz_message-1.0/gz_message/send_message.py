def send(text):
    print("Send: %s" % text)