def receive():
    return "this is message"
